# Project memory

## Product intent & audience

- ZORD: Telegram community agent ecosystem with three specialized agents.
  - **Sentinel** — basic community protection (spam/suspicious-link detection).
  - **Poly-Shield** — advanced multilingual moderation + contextual risk scoring.
  - **Omini Glitch** — community intelligence, reports, content creation/drafting.
- Audience: Telegram community owners/admins; platform administrators.
- Future integration target: existing QUANTUM-AI/ZORD project (Render-hosted agents, Supabase Preview, bot identity @ZORDPreviewBot, approved AI + image-generation APIs). New system built independently; must not modify existing QUANTUM-AI code/db/production.

## Brand personality & voice

- Premium AI security/intelligence platform: sophisticated, restrained, honest about incomplete integrations.
- Each agent has distinct visual identity: Sentinel=protection/reliability; Poly-Shield=advanced intelligence/multilingual; Omini Glitch=powerful AI/creativity.

## Visual design & UX direction

- Modern dark interface, clean typography, professional dashboard layouts.
- Responsive across desktop/tablet/mobile; functionality never sacrificed for visuals.
- Smooth but restrained animations; clear status indicators; useful charts/analytics.
- Agent-specific visual identities must be consistent across dashboards.

## Decisions, constraints & rationale

- Stack: Supabase (DB/auth/RLS) + Vite frontend + serverless functions (webhook).
- Build in 6 phases; Phase 1 complete (architecture, DB, auth, admin dashboard foundation, Telegram webhook infra).
- Phase 1 schema created: admin roles, telegram_communities, telegram update log (for dedup).
- Security: RLS tightened; DB advisor checks pass with no findings.
- Webhook handles: secret validation, update deduplication, `/start`, `/help`, bot-added-to-group.
- Hard rules: never fake API responses, never hardcode secrets, never invent integration endpoints, never bypass auth, never mix community data, never let one agent perform another's restricted duties, never publish/destructive-moderate without authorization.
- Modular architecture with documented integration adapters for future ZORD connection; don't assume Render agent APIs — inspect first.

## Open questions & assumptions

- Pending from user: BotFather token for @ZORDPreviewBot + webhook secret (bot can't reply until set; webhook not yet registered with Telegram).
- Pending from user: admin email to grant administrator role after sign-up.
- Unknown: exact Render-agent API endpoints/auth/schemas for future integration.
- Unknown: which specific AI APIs and image-generation APIs are "approved" for integration.
- Assumption: existing QUANTUM-AI Supabase Preview is a separate project from this build's Supabase instance.
- Phases 2–6 (Sentinel, Poly-Shield, Omini Glitch, subscriptions/payments, Content Studio, scheduled jobs, tests, deployment docs) still pending.